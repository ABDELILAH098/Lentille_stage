function clic(element)
{
  //alert("Cliqué sur " + element.name);
  //alert("L'action a exécuter est " + element.action);
  return false;
}